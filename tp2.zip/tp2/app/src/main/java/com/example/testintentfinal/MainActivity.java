package com.example.testintentfinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText text1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        if ((intent != null)&&(intent.hasExtra("etext"))){
            TextView text3 = findViewById(R.id.text3);
            String var = intent.getStringExtra("etext");
            text3.setText(var);
        }
    }
    public void ChangeActivity(View view){
        Intent Int1 = new Intent (this, SecondActivity.class);
        EditText text1 = (EditText) findViewById(R.id.text1);
        String str = text1.getText().toString();

        Int1.putExtra("etext",str);

        startActivity(Int1);
    }

  public void valider(View view){
        EditText text1 = findViewById(R.id.text1);
      String var2 = text1.getText().toString();
      text1.setText(var2);


  }
}
