package com.example.testintentfinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    TextView text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        if ((intent != null)&&(intent.hasExtra("etext"))){
            TextView text2 = findViewById(R.id.text2);
            String var = intent.getStringExtra("etext");
            text2.setText(var);
        }


    }
    /*public void ChangeActivity2(View view){
        Intent Int1 = new Intent (this, MainActivity.class);
        TextView Et1 = (TextView) findViewById(R.id.text2);
        String str = Et1.getText().toString();

        Int1.putExtra("mtext",str);

        startActivity(Int1);
    }
*/
    public void Majuscule (View view){

        TextView text2 = findViewById(R.id.text2);
        String str2 = text2.getText().toString();
        String maj = str2.toUpperCase();
        Intent Int1 = new Intent (this, MainActivity.class);
        Int1.putExtra("etext",maj);
        startActivity(Int1);
    }


    public void Inverser (View view){

        TextView text2 = findViewById(R.id.text2);
        String str3 = new StringBuilder().reverse().toString();
        String maj2 = str3.toUpperCase();
        Intent Int1 = new Intent (this, MainActivity.class);
        Int1.putExtra("etext",maj2);
        startActivity(Int1);

    }



}
