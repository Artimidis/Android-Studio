package com.example.testimplicitcastrosilva;

import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private Button message;
    private Button mms;
    private Button appel;
    private Button web;
    private Button map;
    private EditText numero;
    private EditText url;
    private EditText longitude;
    private EditText latitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        message = (Button) findViewById(R.id.sms);
        mms = (Button) findViewById(R.id.mms);
        appel = (Button) findViewById(R.id.appel);
        web = (Button) findViewById(R.id.web);
        map = (Button) findViewById(R.id.map);

        numero = (EditText) findViewById(R.id.numero);
        url = (EditText) findViewById(R.id.url);
        longitude = (EditText) findViewById(R.id.longitude);
        latitude = (EditText) findViewById(R.id.latitude);


    }

    public void Callback(View v) {
        String strl = numero.getText().toString();
        String internet = url.getText().toString();
        String longi = longitude.getText().toString();
        String latitu = latitude.getText().toString();

        switch (v.getId()) {
            case R.id.sms:
                System.out.println("sms");
                Uri uri = Uri.parse("sms:" +strl);
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", "my message");
                startActivity(intent);
                break;

            case R.id.mms:
                System.out.println("mms");
                Uri uri2 = Uri.parse("content://media/external/images/media" +strl);
                Intent intent2 = new Intent(Intent.ACTION_SENDTO, uri2);
                intent2.putExtra(Intent.EXTRA_STREAM, uri2);
                intent2.setType("image/");
                startActivity(intent2);
                break;

            case R.id.appel:
                System.out.println("appel");
                Uri call = Uri.parse("tel:" +strl);
                Intent intent3 = new Intent(Intent.ACTION_DIAL, call);
                startActivity(intent3);
                break;

            case R.id.web:
                System.out.println("web");
                Uri site = Uri.parse(internet);
                Intent intent4 = new Intent(Intent.ACTION_VIEW, site);
                startActivity(intent4);
                break;

            case R.id.map:
                System.out.println("map");
                Uri gmmIntentUri = Uri.parse("geo:"+latitu+", "+longi);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
                break;
        }
    }
}