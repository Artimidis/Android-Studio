package com.example.testintent02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        if ((intent != null)&&(intent.hasExtra("mtext"))){
            TextView text1 = findViewById(R.id.text);
            String var = intent.getStringExtra("mtext");
            text1.setText(var);
        }
    }
    public void ChangeActivity(View view){
        Intent Int1 = new Intent (this, SecondActivity.class);
        TextView text1 = (TextView) findViewById(R.id.text);
        String str = text1.getText().toString();

        Int1.putExtra("etext",str);

        startActivity(Int1);
    }
}

