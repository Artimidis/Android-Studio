package com.example.tp4intent01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView text1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        if ((intent != null)&&(intent.hasExtra("mtext"))){
            TextView text1 = findViewById(R.id.text1);
            String var = intent.getStringExtra("mtext");
            text1.setText(var);
        }
    }
    public void ChangeActivity(View view){
        Intent Int1 = new Intent (this, SecondActivity.class);
        TextView text1 = (TextView) findViewById(R.id.text1);
        String str = text1.getText().toString();

        Int1.putExtra("etext",str);

        startActivity(Int1);
    }
}
