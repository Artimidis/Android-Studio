package com.example.castrosilvaanime;

import android.animation.ValueAnimator;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button commencer;
    private Button arriere;
    private ConstraintLayout background;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        commencer = (Button) findViewById(R.id.start);
        arriere = (Button) findViewById(R.id.reverse);
        background = (ConstraintLayout) findViewById(R.id.constraintLayout);

        commencer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        arriere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                va.reverse();
            }
        });

        public static void changeColor (ConstraintLayout) {
                ValueAnimator animator = ValueAnimator.ofArgb(0xff000000, 0xffffffff);
                ValueAnimator va = ValueAnimator.ofFloat(0xff000000, 0xffffffff);
                va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                background.setTranslationX((float) animation.getAnimatedValue());
                /*@Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    view.setBackgroundColor((Integer)valueAnimator.getAnimatedValue());
                }*/
            }
        });
        va.start();
        }
    }
}
