package com.example.testintent01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    EditText text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        EditText text2 = findViewById(R.id.text2);
        String var = intent.getStringExtra("etext");
        text2.setText(var);

    }
    public void ChangeActivity2(View view){
        Intent Int1 = new Intent (this, SecondActivity.class);
        EditText Et1 = (EditText) findViewById(R.id.text2);
        String str = Et1.getText().toString();

        Int1.putExtra("etext",str);

        startActivity(Int1);
    }
}
