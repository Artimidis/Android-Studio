package com.example.tpimagecastrosilva;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.FileNotFoundException;

public class MainActivity extends AppCompatActivity {

    private Button charger;
    private ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        charger = (Button) findViewById(R.id.charger);
        image = (ImageView) findViewById(R.id.imageView);

    }

    public void onStart() {
        charger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("charger");
                Uri uri = Uri.parse("content://storage/emulated/0/DCIM/Camera/");
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT, uri);
                BitmapFactory.Options option = new BitmapFactory.Options();
                option.inMutable = true;
                Bitmap bm = BitmapFactory.decodeStream(getContentResolver().openInputStream(uri),null, option);
                startActivity(intent);
        }
    });
}
}
